from django.shortcuts import render, redirect
from django.urls import reverse

from patient.models import userregistration

from patient.models import symptomrecord

from patient.models import diagnosis

from patient.models import prescription

from patient.models import payment

from patient.models import patientprofile

from patient.models import notification

from patient.models import medicalhistory

from patient.models import labresult

from patient.models import labtest

from patient.models import feedback

from patient.models import doctorprofile

from patient.models import userlogin


# Create your views here.

def logcheck(request):
    if request.method=="POST":
        username=request.POST.get('t1')
        password = request.POST.get('t2')
        count=userlogin.objects.filter(username=username).count()
        if count>=1:
            udata=userlogin.objects.get(username=username)
            request.session['username'] = username
            upass=udata.password
            utype=udata.type
            if upass==password:
                if utype=='admin':
                    return render(request,'admin_home.html')
                if utype=='doctor':
                    return render(request,'doctor_home.html')
                if utype=='patient':
                    return render(request,'patient_home.html')

            else:
                return render(request,'login.html',{'msg':'invalid password'})
        else:
            return render(request, 'login.html', {'msg': 'invalid username'})

    return render(request,'login.html')

def showindex(request):
    return render(request,'index.html',)

def logout(request):
    if 'username' in request.session:
        del request.session['username']
    return redirect('logcheck')


def insertuserreg(request):

    if request.method=="POST":
        s1=request.POST.get("t1")
        s2 = request.POST.get("t2")
        s3 = request.POST.get("t3")
        s4 = request.POST.get("t4")
        s5 = request.POST.get("t5")
        s6 = request.POST.get("t6")
        s7= request.POST.get("t7")

        userregistration.objects.create(name=s1,email=s2,password=s3,contact=s4,city=s5,address=s6,role=s7)
        return render(request,"userregistrationinfo.html")
    return render(request,"userregistrationinfo.html")

def showusereg(request):
    userdict=userregistration.objects.all()
    return render(request,"viewuseregistration.html",{'userdict':userdict})

def deluserreg(request,pk):
    id=userregistration.objects.get(id=pk)
    id.delete()
    userdict = userregistration.objects.all()
    return render(request, "viewuseregistration.html", {'userdict': userdict})



def insertsymptom(request):

    if request.method=="POST":
        s1=request.POST.get("t1")
        s2 = request.POST.get("t2")
        s3 = request.POST.get("t3")
        s4 = request.POST.get("t4")
        s5 = request.POST.get("t5")
        s6 = request.POST.get("t6")
        s7 = request.POST.get("t7")


        symptomrecord.objects.create(patient=s1,symptom_name=s2,severity=s3,duration=s4,body_part=s5,recorded_date=s6,description=s7)
        return render(request,"symptomsinfo.html")
        return render(request,"symptomsinfo.html")
    return render(request,"symptomsinfo.html")

def showsymptom(request):
    userdict=symptomrecord.objects.all()
    return render(request,"viewsymptoms.html",{'userdict':userdict})

def delsymptom(request,pk):
    id=symptomrecord.objects.get(id=pk)
    id.delete()
    userdict = symptomrecord.objects.all()
    return render(request, "viewsymptoms.html", {'userdict': userdict})



def daignosis1(request):

    if request.method=="POST":
        s1=request.POST.get("t1")
        s2 = request.POST.get("t2")
        s3 = request.POST.get("t3")
        s4 = request.POST.get("t4")
        s5 = request.POST.get("t5")
        s6 = request.POST.get("t6")
        s7 = request.POST.get("t7")
        s8 = request.POST.get("t8")


        diagnosis.objects.create(patient=s1,doctor=s2,diagnosis_date=s3,condition_name=s4,diagnosis_type=s5,description=s6,severity_level=s7,follow_up_date=s8)
        return render(request,"diagnosisinfo.html")
    return render(request,"diagnosisinfo.html")

def showdiagnosis(request):
    userdict=diagnosis.objects.all()
    return render(request,"viewdiagnosis.html",{'userdict':userdict})

def deldiagnosis(request,pk):
    id=diagnosis.objects.get(id=pk)
    id.delete()
    userdict = diagnosis.objects.all()
    return render(request, "viewdiagnosis.html", {'userdict': userdict})



def insertprescript(request):

    if request.method=="POST":
        s1=request.POST.get("t1")
        s2 = request.POST.get("t2")
        s3 = request.POST.get("t3")
        s4 = request.POST.get("t4")
        s5 = request.POST.get("t5")
        s6 = request.POST.get("t6")
        s7 = request.POST.get("t7")


        prescription.objects.create(diagnosis=s1,medicine_name=s2,dosage=s3,frequency=s4,duration=s5,instructions=s6,prescribed_date=s7)
        return render(request,"prescriptioninfo.html")
    return render(request,"prescriptioninfo.html")

def showprescription(request):
    userdict=prescription.objects.all()
    return render(request,"viewprescription.html",{'userdict':userdict})

def delprescription(request,pk):
    id=prescription.objects.get(id=pk)
    id.delete()
    userdict = prescription.objects.all()
    return render(request, "viewprescription.html", {'userdict': userdict})



def insertpayment(request):

    if request.method=="POST":
        s1=request.POST.get("t1")
        s2 = request.POST.get("t2")
        s3 = request.POST.get("t3")
        s4 = request.POST.get("t4")
        s5 = request.POST.get("t5")
        s6 = request.POST.get("t6")
        s7 = request.POST.get("t7")
        s8 = request.POST.get("t8")

        payment.objects.create(patient=s1,diagnosis=s2,lab_test=s3,amount=s4,payment_date=s5,payment_method=s6,transaction_id=s7,status=s8)
        return render(request,"paymentinfo.html")
    return render(request,"paymentinfo.html")

def showmpayment(request):
    userdict=payment.objects.all()
    return render(request,"viewpayment.html",{'userdict':userdict})

def delpayment(request,pk):
    id=payment.objects.get(id=pk)
    id.delete()
    userdict = payment.objects.all()
    return render(request, "viewpayment.html", {'userdict': userdict})



def insertpatient(request):

    if request.method=="POST":
        s1=request.POST.get("t1")
        s2 = request.POST.get("t2")
        s3 = request.POST.get("t3")
        s4 = request.POST.get("t4")
        s5 = request.POST.get("t5")
        s6 = request.POST.get("t6")
        s7 = request.POST.get("t7")
        s8 = request.POST.get("t8")

        patientprofile.objects.create(user=s1,age=s2,gender=s3,blood_group=s4,weight=s5,height=s6,existing_conditions=s7,allergies=s8)
        return render(request,"patientprofileinfo.html")
        return render(request,"prescriptioninfo.html")
    return render(request,"patientprofileinfo.html")

def showmpatient(request):
    userdict=patientprofile.objects.all()
    return render(request,"viewpatientprofie.html",{'userdict':userdict})

def delpatient(request,pk):
    id=patientprofile.objects.get(id=pk)
    id.delete()
    userdict = patientprofile.objects.all()
    return render(request, "viewpatientprofie.html", {'userdict': userdict})



def insertnotification(request):

    if request.method=="POST":
        s1=request.POST.get("t1")
        s2 = request.POST.get("t2")
        s3 = request.POST.get("t3")
        s4 = request.POST.get("t4")
        s5 = request.POST.get("t5")

        notification.objects.create(user=s1,message=s2,notification_type=s3,is_read=s4,created_date=s5)
        return render(request,"userregistrationinfo.html")
    return render(request,"userregistrationinfo.html")

def showmnotification(request):
    userdict=notification.objects.all()
    return render(request,"viewnotification.html",{'userdict':userdict})

def delnotification(request,pk):
    id=notification.objects.get(id=pk)
    id.delete()
    userdict = notification.objects.all()
    return render(request, "viewnotification.html", {'userdict': userdict})



def insertmedihistory(request):

    if request.method=="POST":
        s1=request.POST.get("t1")
        s2 = request.POST.get("t2")
        s3 = request.POST.get("t3")
        s4 = request.POST.get("t4")
        s5 = request.POST.get("t5")
        s6 = request.POST.get("t6")


        medicalhistory.objects.create(patient=s1,diagnosis=s2,treatment_summary=s3,outcome=s4,date_recorded=s5,notes=s6,)
        return render(request,"medicallhistoryinfo.html")
    return render(request,"medicallhistoryinfo.html")

def showmedicalhistory(request):
    userdict=medicalhistory.objects.all()
    return render(request,"viewmedicalhistory.html",{'userdict':userdict})

def delmedicalhistory(request,pk):
    id=medicalhistory.objects.get(id=pk)
    id.delete()
    userdict = medicalhistory.objects.all()
    return render(request, "viewmedicalhistory.html", {'userdict': userdict})


def insertlabtest(request):

    if request.method=="POST":
        s1=request.POST.get("t1")
        s2 = request.POST.get("t2")
        s3 = request.POST.get("t3")
        s4 = request.POST.get("t4")
        s5 = request.POST.get("t5")
        s6 = request.POST.get("t6")
        s7 = request.POST.get("t7")
        s8 = request.POST.get("t8")

        labtest.objects.create(patient=s1,diagnosis=s2,test_name=s3,test_type=s4,prescribed_by=s5,test_date=s6,status=s7,cost=s8)
        return render(request,"labtest.html")
    return render(request,"labtest.html")

def showlabtest(request):
    userdict=labtest.objects.all()
    return render(request,"viewlabtest.html",{'userdict':userdict})

def dellabtest(request,pk):
    id=labtest.objects.get(id=pk)
    id.delete()
    userdict = labtest.objects.all()
    return render(request, "viewlabtest.html", {'userdict': userdict})

def insertlabresult(request):

    if request.method=="POST":
        s1=request.POST.get("t1")
        s2 = request.POST.get("t2")
        s3 = request.POST.get("t3")
        s4 = request.POST.get("t4")
        s5 = request.POST.get("t5")
        s6 = request.POST.get("t6")
        s7 = request.POST.get("t7")

        labresult.objects.create(lab_test=s1,result_value=s2,normal_range=s3,result_status=s4,report_date=s5,technician_name=s6,report_file=s7)
        return render(request,"labresultinfo.html")
    return render(request,"labresultinfo.html")

def showlabresult(request):
    userdict=labresult.objects.all()
    return render(request,"viewlabresultinfo.html",{'userdict':userdict})

def dellabresult(request,pk):
    id=labresult.objects.get(id=pk)
    id.delete()
    userdict = labresult.objects.all()
    return render(request, "viewlabresultinfo.html", {'userdict': userdict})



def insertfeedback(request):

    if request.method=="POST":
        s1=request.POST.get("t1")
        s2 = request.POST.get("t2")
        s3 = request.POST.get("t3")
        s4 = request.POST.get("t4")
        s5 = request.POST.get("t5")

        feedback.objects.create(patient=s1,doctor=s2,rating=s3,comments=s4,feedback_date=s5)
        return render(request,"feedbackinfo.html")
    return render(request,"feedbackinfo.html")


def showfeedback(request):
    userdict=feedback.objects.all()
    return render(request,"viewfeedback.html",{'userdict':userdict})

def delfeedback(request,pk):
    id=feedback.objects.get(id=pk)
    id.delete()
    userdict = feedback.objects.all()
    return render(request, "viewfeedback.html", {'userdict': userdict})



def insertdoctor(request):

    if request.method=="POST":
        s1 = request.POST.get("t1")
        s2 = request.POST.get("t2")
        s3 = request.POST.get("t3")
        s4 = request.POST.get("t4")
        s5 = request.POST.get("t5")
        s6 = request.POST.get("t6")
        s7 = request.POST.get("t7")
        s8 = request.POST.get("t8")

        doctorprofile.objects.create(user=s1,specialization=s2,qualification=s3,experience_years=s4,hospital_name=s5,consultation_fee=s6,available_time=s7,photo=s8)
        return render(request,"docprofileinfo.html")

    return render(request,"docprofileinfo.html")

def showdoctor(request):
    userdict=doctorprofile.objects.all()
    return render(request,"viewdoctorprofileinfo.html",{'userdict':userdict})

def deldoctor(request,pk):
    id=doctorprofile.objects.get(id=pk)
    id.delete()
    userdict = doctorprofile.objects.all()
    return render(request, "viewdoctorprofileinfo.html", {'userdict': userdict})



def insertlogin(request):

    if request.method=="POST":
        s1=request.POST.get("t1")
        s2 = request.POST.get("t2")
        s3 = request.POST.get("t3")


        userlogin.objects.create(username=s1,password=s2,type=s3)
        return render(request,"login.html")
    return render(request,"login.html")

def showlogin(request):
    userdict=userlogin.objects.all()
    return render(request,"viewlogin.html",{'userdict':userdict})

def dellogin(request,pk):
    id=userlogin.objects.get(id=pk)
    id.delete()
    userdict = userlogin.objects.all()
    return render(request, "viewlogin.html", {'userdict': userdict})

def showindex(request):
    return render(request,"index.html")

